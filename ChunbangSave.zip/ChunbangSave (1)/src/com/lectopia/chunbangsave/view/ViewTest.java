package com.lectopia.chunbangsave.view;

import java.util.GregorianCalendar;

import javax.swing.JDialog;
import javax.swing.JFrame;

public class ViewTest {

	public static void main(String[] args) {
		JFrame frame = new JFrame();
		//GregorianCalendar calendar = new GregorianCalendar();
		//new ParentJoinUI(frame);
		new LoginUI();
		//new MainUI();
	//	new DayAccountUI(frame,calendar,1);
		//new CommunicationWithParent(frame, 1);
		JDialog dialog = new JDialog();
		//new NeedAllowanceUI(dialog, calendar, 1);
	}

}
